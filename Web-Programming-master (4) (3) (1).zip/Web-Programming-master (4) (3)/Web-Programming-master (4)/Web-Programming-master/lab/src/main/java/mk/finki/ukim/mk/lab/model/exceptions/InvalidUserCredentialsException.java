package mk.finki.ukim.mk.lab.model.exceptions;



public class InvalidUserCredentialsException extends RuntimeException {
  public InvalidUserCredentialsException() {
    super("Invalid user credentials exception");
  }
}
